/*import React from 'react';
import Counter from './counter';

function Welcome(props){
  return <h2>Welcome, {props.name}</h2>
}

function App() {
  return (
    
    <div>
      <Welcome name = "Gabriella"/>
      <Welcome name = "Dale"/>
      <Welcome name = "Lou"/>
    </div>
    
    
    <div>
    <Counter/>
   </div>
  )
   };

import React, { useState } from 'react';
import './App.css';

const imageUrls = [
  'https://thumbs.dreamstime.com/b/bunch-bananas-6175887.jpg?w=768',
  'https://thumbs.dreamstime.com/z/full-body-brown-chicken-hen-standing-isolated-white-backgroun-background-use-farm-animals-livestock-theme-49741285.jpg?ct=jpeg',
  'https://thumbs.dreamstime.com/b/bunch-bananas-6175887.jpg?w=768',
  'https://thumbs.dreamstime.com/z/full-body-brown-chicken-hen-standing-isolated-white-backgroun-background-use-farm-animals-livestock-theme-49741285.jpg?ct=jpeg',
  'https://thumbs.dreamstime.com/b/bunch-bananas-6175887.jpg?w=768',
  'https://thumbs.dreamstime.com/z/full-body-brown-chicken-hen-standing-isolated-white-backgroun-background-use-farm-animals-livestock-theme-49741285.jpg?ct=jpeg',

];

function getRandomImage() {
  const index = Math.floor(Math.random(50) * imageUrls.length);
  return imageUrls[index];
}

function App() {
  const [images, setImages] = useState(Array(36).fill().map(getRandomImage));
  const [board, setBoard] = useState(Array(36).fill(null));
  const newBoard = [...board];


  const handleClick = () => {
    setImages(images.map(() => getRandomImage()));
  };

   const rows = [];
  for (let i = 0; i < 6; i++) {
    rows.push(images.slice(i * 6, i * 6 + 6));
  }

 return (
    <div className="container">
      <h1>Chicken Banana Game!</h1>
      <table>
        <tbody>
          {rows.map((row, rowIndex) => (
            <tr key={rowIndex}>
              {row.map((img, colIndex) => (
                <td key={colIndex}>
                  <img
                    src={img}
                    alt="Random"
                    className="square"
                    onClick={handleClick}
                  />
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
*/




import React, { useState, useEffect } from 'react';
import './App.css';

const bananaImg = 'https://thumbs.dreamstime.com/b/bunch-bananas-6175887.jpg?w=768';
const chickenImg = 'https://thumbs.dreamstime.com/z/full-body-brown-chicken-hen-standing-isolated-white-backgroun-background-use-farm-animals-livestock-theme-49741285.jpg?ct=jpeg'
  ;

const getRandomWinningCells = () => {
const indices = new Set();
while (indices.size < 3) {
indices.add(Math.floor(Math.random() * 36));
}
return Array.from(indices);
};

function App() {
const [player, setPlayer] = useState(null);
const [board, setBoard] = useState(Array(36).fill(null));
const [winningCells, setWinningCells] = useState([]);
const [gameStatus, setGameStatus] = useState('');

useEffect(() => {
setWinningCells(getRandomWinningCells());
}, []);

const handleCellClick = (index) => {
if (!player || board[index] || gameStatus) return;

const newBoard = [...board];

const isBanana = Math.random() < 0.5;
const revealedImage = isBanana ? bananaImg : chickenImg;
newBoard[index] = revealedImage;
setBoard(newBoard);

const isWin = (player === 'Banana' && isBanana) || (player === 'Chicken' && !isBanana);

if (isWin) {
setGameStatus('You WIN!');
} else if (!newBoard.includes(null)) {
setGameStatus('You LOSE!');
}
};

const handleReset = () => {
setBoard(Array(36).fill(null));
setWinningCells(getRandomWinningCells());
setGameStatus('');
setPlayer(null);
};

return (
<div className="container">
<h1>Chicken or Banana</h1>
<p>Choose your player:</p>
<div>
<button onClick={() => setPlayer('Chicken')} disabled={player !== null}>Chicken</button>
<button onClick={() => setPlayer('Banana')} disabled={player !== null}>Banana</button>
</div>
<div className="grid">
{board.map((img, index) => (
<div
key={index}
className="cell"
onClick={() => handleCellClick(index)}
>
{img && <img src={img} alt="choice" />}
</div>
))}
</div>
{gameStatus && <h2>{gameStatus}</h2>}
<button onClick={handleReset} style={{ marginTop: '15px' }}>Reset Game</button>
</div>
);
}
export default App;
